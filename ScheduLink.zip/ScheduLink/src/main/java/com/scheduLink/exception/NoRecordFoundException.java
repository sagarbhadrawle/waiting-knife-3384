package com.scheduLink.exception;

public class NoRecordFoundException extends Exception {
	public NoRecordFoundException(String msg) {
		 super(msg);
	}
}
