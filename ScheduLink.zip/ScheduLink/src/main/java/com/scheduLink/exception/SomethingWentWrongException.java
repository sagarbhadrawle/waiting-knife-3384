package com.scheduLink.exception;

public class SomethingWentWrongException extends Exception {
	public SomethingWentWrongException(String msg){
		super(msg);
	}
}
